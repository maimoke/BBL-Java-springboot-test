package com.example.accessingdatamysql;

public class UserForm {
    public String name;
    public String username;
    public String email;
    public Address address;
    public String phone;
    public String website;
    public Company company;
}